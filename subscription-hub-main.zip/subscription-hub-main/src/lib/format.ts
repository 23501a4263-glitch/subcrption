export const formatCurrency = (n: number, currency = "USD") =>
  new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(n || 0);

export const formatDate = (d: string | Date) =>
  new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

export const daysUntil = (d: string | Date) => {
  const ms = new Date(d).getTime() - Date.now();
  return Math.ceil(ms / (1000 * 60 * 60 * 24));
};

export const monthlyAmount = (amount: number, cycle: string) => {
  switch (cycle) {
    case "yearly": return amount / 12;
    case "weekly": return (amount * 52) / 12;
    case "quarterly": return amount / 3;
    default: return amount;
  }
};

export const CATEGORIES = [
  "Streaming", "Music", "Productivity", "Cloud Storage", "Gaming",
  "News", "Fitness", "Education", "AI Tools", "Software", "Other",
] as const;

export const CATEGORY_COLORS: Record<string, string> = {
  Streaming: "oklch(0.7 0.2 25)",
  Music: "oklch(0.7 0.2 145)",
  Productivity: "oklch(0.7 0.2 250)",
  "Cloud Storage": "oklch(0.7 0.2 195)",
  Gaming: "oklch(0.7 0.2 320)",
  News: "oklch(0.7 0.18 75)",
  Fitness: "oklch(0.7 0.2 165)",
  Education: "oklch(0.7 0.2 280)",
  "AI Tools": "oklch(0.7 0.22 295)",
  Software: "oklch(0.7 0.2 220)",
  Other: "oklch(0.6 0.05 265)",
};
