import { useEffect, useState } from "react";
import type { Database } from "@/integrations/supabase/types";
import { supabase } from "@/integrations/supabase/client";

export type Subscription = Database["public"]["Tables"]["subscriptions"]["Row"];

export function useSubscriptions(userId: string | undefined) {
  const [data, setData] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    if (!userId) return;
    setLoading(true);
    const { data: rows, error } = await supabase
      .from("subscriptions")
      .select("*")
      .order("next_renewal", { ascending: true });
    if (!error && rows) setData(rows);
    setLoading(false);
  };

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [userId]);

  return { data, loading, refresh };
}
