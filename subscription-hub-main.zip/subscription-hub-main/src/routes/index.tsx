import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { ArrowRight, BarChart3, Bell, CreditCard, Sparkles, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session) throw redirect({ to: "/dashboard" });
  },
  component: Landing,
});

const FEATURES = [
  { icon: CreditCard, title: "All your subscriptions", body: "Netflix, Notion, ChatGPT — one tidy list with logos, prices, and renewal dates." },
  { icon: BarChart3, title: "Spending analytics", body: "Beautiful charts that show exactly where your money goes each month." },
  { icon: Bell, title: "Smart reminders", body: "Get a heads-up days before a renewal — never get blindsided again." },
  { icon: ShieldCheck, title: "Private by default", body: "Your data is yours. Encrypted at rest, scoped per-user, no creepy tracking." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background bg-mesh">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </span>
          Flux
        </Link>
        <div className="flex items-center gap-2">
          <Link to="/login" className="rounded-xl px-4 py-2 text-sm font-medium hover:bg-accent">Sign in</Link>
          <Link to="/signup" className="rounded-xl bg-gradient-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-glow">
            Get started
          </Link>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 pb-20 pt-12 sm:pt-20">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Now tracking AI tool subscriptions
          </span>
          <h1 className="mt-6 text-5xl font-display leading-[1.05] sm:text-6xl">
            Every subscription.<br />
            <span className="text-gradient-primary">One calm dashboard.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
            Flux quietly tracks every recurring charge so you stop overpaying for things you forgot you signed up for.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link to="/signup" className="inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-glow transition hover:opacity-90">
              Start tracking free <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/login" className="rounded-xl border border-border bg-card/60 px-6 py-3 text-sm font-medium backdrop-blur hover:bg-accent">
              I have an account
            </Link>
          </div>
        </div>

        {/* mock dashboard preview */}
        <div className="relative mx-auto mt-16 max-w-5xl">
          <div className="absolute inset-0 -z-10 mx-12 my-8 rounded-3xl bg-gradient-primary opacity-30 blur-3xl" />
          <div className="glass overflow-hidden rounded-3xl shadow-glow">
            <div className="grid grid-cols-3 gap-4 p-4 sm:p-6">
              {[
                { label: "Active subs", value: "14", trend: "+2 this month" },
                { label: "Monthly spend", value: "$284.50", trend: "−$12 vs last month" },
                { label: "Next 7 days", value: "3", trend: "renewals" },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl border border-border bg-card/40 p-4">
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className="mt-2 font-display text-2xl">{s.value}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{s.trend}</p>
                </div>
              ))}
            </div>
            <div className="border-t border-border/50 p-4 sm:p-6">
              <div className="flex items-end gap-1.5 h-32">
                {[40, 60, 50, 75, 65, 90, 80, 100, 70, 85, 95, 110].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t-md bg-gradient-primary opacity-80"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-24 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map(({ icon: Icon, title, body }) => (
            <div key={title} className="glass rounded-2xl p-6">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
                <Icon className="h-4 w-4 text-primary-foreground" />
              </span>
              <h3 className="mt-4 font-display text-lg">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Flux — Built with ♡ on Lovable
      </footer>
    </div>
  );
}
