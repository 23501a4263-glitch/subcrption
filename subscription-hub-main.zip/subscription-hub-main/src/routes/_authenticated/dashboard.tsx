import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip,
  PieChart, Pie, Cell,
} from "recharts";
import { CalendarClock, Coins, Layers, TrendingUp, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useSubscriptions } from "@/lib/use-subscriptions";
import { CATEGORY_COLORS, daysUntil, formatCurrency, formatDate, monthlyAmount } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: Page });

function Page() {
  const { user } = useAuth();
  const { data, loading } = useSubscriptions(user?.id);

  const stats = useMemo(() => {
    const active = data.filter((s) => s.status === "active");
    const monthly = active.reduce((sum, s) => sum + monthlyAmount(Number(s.amount), s.billing_cycle), 0);
    const upcoming = active.filter((s) => daysUntil(s.next_renewal) >= 0 && daysUntil(s.next_renewal) <= 7);
    const expired = data.filter((s) => s.status === "expired" || s.status === "cancelled");
    return { total: data.length, monthly, upcoming, active: active.length, expired: expired.length };
  }, [data]);

  const chartData = useMemo(() => {
    // last 6 months mock based on current monthly run-rate (replace with payments when implemented)
    const now = new Date();
    return Array.from({ length: 6 }).map((_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
      const factor = 0.8 + Math.random() * 0.4;
      return { month: d.toLocaleString("en", { month: "short" }), spend: Math.round(stats.monthly * factor) };
    });
  }, [stats.monthly]);

  const pieData = useMemo(() => {
    const map: Record<string, number> = {};
    data.filter((s) => s.status === "active").forEach((s) => {
      const m = monthlyAmount(Number(s.amount), s.billing_cycle);
      map[s.category] = (map[s.category] ?? 0) + m;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }));
  }, [data]);

  if (loading) return <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="font-display text-3xl">Hey {user?.user_metadata?.full_name?.split(" ")[0] ?? "there"} 👋</h1>
          <p className="mt-1 text-sm text-muted-foreground">Here's a quick look at your subscriptions today.</p>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi icon={Layers} label="Total subscriptions" value={String(stats.total)} hint={`${stats.active} active`} />
        <Kpi icon={Coins} label="Monthly spend" value={formatCurrency(stats.monthly)} hint="across active subs" />
        <Kpi icon={CalendarClock} label="Renewals next 7 days" value={String(stats.upcoming.length)} hint="don't get blindsided" />
        <Kpi icon={TrendingUp} label="Active vs ended" value={`${stats.active} / ${stats.expired}`} hint="active / cancelled" />
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="glass rounded-2xl p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-lg">Spending trend</h3>
              <p className="text-xs text-muted-foreground">Last 6 months</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickLine={false} axisLine={false} width={40} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12 }} />
                <Area type="monotone" dataKey="spend" stroke="var(--color-primary)" strokeWidth={2} fill="url(#g1)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-lg">By category</h3>
          <p className="text-xs text-muted-foreground">Monthly equivalent</p>
          {pieData.length === 0 ? (
            <p className="mt-12 text-center text-sm text-muted-foreground">Add a subscription to see this chart.</p>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                    {pieData.map((d, i) => <Cell key={i} fill={CATEGORY_COLORS[d.name] ?? "var(--color-primary)"} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Upcoming renewals */}
      <div className="glass rounded-2xl p-6">
        <h3 className="font-display text-lg">Upcoming renewals</h3>
        <p className="text-xs text-muted-foreground">The next few payments coming up</p>
        <div className="mt-4 divide-y divide-border/50">
          {data.filter((s) => s.status === "active").slice(0, 6).map((s) => (
            <div key={s.id} className="flex items-center gap-4 py-3">
              <Logo url={s.logo_url} name={s.name} color={s.color} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{s.name}</p>
                <p className="text-xs text-muted-foreground">{s.category} · {formatDate(s.next_renewal)}</p>
              </div>
              <div className="text-right">
                <p className="font-medium">{formatCurrency(Number(s.amount), s.currency)}</p>
                <p className="text-xs text-muted-foreground">{s.billing_cycle}</p>
              </div>
            </div>
          ))}
          {data.length === 0 && (
            <p className="py-12 text-center text-sm text-muted-foreground">No subscriptions yet — add your first one to get started.</p>
          )}
        </div>
      </div>
    </div>
  );
}

function Kpi({ icon: Icon, label, value, hint }: { icon: React.ComponentType<{className?: string}>; label: string; value: string; hint: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">{label}</p>
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary"><Icon className="h-4 w-4 text-primary-foreground" /></span>
      </div>
      <p className="mt-3 font-display text-2xl">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

export function Logo({ url, name, color }: { url: string | null; name: string; color: string | null }) {
  if (url) return <img src={url} alt={name} className="h-10 w-10 rounded-xl object-cover" />;
  const bg = color || "var(--color-primary)";
  return (
    <div className="flex h-10 w-10 items-center justify-center rounded-xl text-sm font-semibold text-white" style={{ background: bg }}>
      {name[0]?.toUpperCase()}
    </div>
  );
}
