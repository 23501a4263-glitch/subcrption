import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Plus, Search, Trash2, Pencil, X, Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { useSubscriptions, type Subscription } from "@/lib/use-subscriptions";
import { CATEGORIES, formatCurrency, formatDate } from "@/lib/format";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "./dashboard";

export const Route = createFileRoute("/_authenticated/subscriptions")({ component: Page });

function Page() {
  const { user } = useAuth();
  const { data, loading, refresh } = useSubscriptions(user?.id);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [editing, setEditing] = useState<Subscription | null>(null);
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() =>
    data.filter((s) =>
      (cat === "all" || s.category === cat) &&
      (q === "" || s.name.toLowerCase().includes(q.toLowerCase()))
    ), [data, q, cat]);

  const onDelete = async (id: string) => {
    if (!confirm("Delete this subscription?")) return;
    const { error } = await supabase.from("subscriptions").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    refresh();
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Subscriptions</h1>
          <p className="mt-1 text-sm text-muted-foreground">Manage everything you're paying for.</p>
        </div>
        <button
          onClick={() => { setEditing(null); setOpen(true); }}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-glow"
        >
          <Plus className="h-4 w-4" /> Add subscription
        </button>
      </div>

      <div className="glass flex flex-wrap items-center gap-3 rounded-2xl p-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..."
            className="w-full rounded-xl border border-input bg-card px-9 py-2 text-sm outline-none focus:border-primary" />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)}
          className="rounded-xl border border-input bg-card px-3 py-2 text-sm outline-none">
          <option value="all">All categories</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex h-48 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
      ) : filtered.length === 0 ? (
        <div className="glass rounded-2xl p-12 text-center">
          <p className="font-display text-lg">No subscriptions yet</p>
          <p className="mt-2 text-sm text-muted-foreground">Click "Add subscription" to track your first one.</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s) => (
            <div key={s.id} className="glass group rounded-2xl p-5 transition hover:shadow-glow">
              <div className="flex items-start gap-3">
                <Logo url={s.logo_url} name={s.name} color={s.color} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{s.name}</p>
                  <p className="text-xs text-muted-foreground">{s.category}</p>
                </div>
                <StatusBadge status={s.status} />
              </div>
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <p className="font-display text-2xl">{formatCurrency(Number(s.amount), s.currency)}</p>
                  <p className="text-xs text-muted-foreground">{s.billing_cycle} · renews {formatDate(s.next_renewal)}</p>
                </div>
                <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                  <button onClick={() => { setEditing(s); setOpen(true); }} className="rounded-lg p-2 hover:bg-accent"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => onDelete(s.id)} className="rounded-lg p-2 text-destructive hover:bg-accent"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && <EditDialog sub={editing} userId={user!.id} onClose={() => setOpen(false)} onSaved={() => { setOpen(false); refresh(); }} />}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    active: "bg-success/15 text-success",
    paused: "bg-warning/15 text-warning",
    cancelled: "bg-muted text-muted-foreground",
    expired: "bg-destructive/15 text-destructive",
  };
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${styles[status] ?? styles.active}`}>{status}</span>;
}

function EditDialog({ sub, userId, onClose, onSaved }: { sub: Subscription | null; userId: string; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(sub?.name ?? "");
  const [category, setCategory] = useState(sub?.category ?? "Streaming");
  const [amount, setAmount] = useState(String(sub?.amount ?? ""));
  const [currency, setCurrency] = useState(sub?.currency ?? "USD");
  const [cycle, setCycle] = useState(sub?.billing_cycle ?? "monthly");
  const [renewal, setRenewal] = useState(sub?.next_renewal ?? new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10));
  const [status, setStatus] = useState(sub?.status ?? "active");
  const [autoRenew, setAutoRenew] = useState(sub?.auto_renew ?? true);
  const [website, setWebsite] = useState(sub?.website ?? "");
  const [logoUrl, setLogoUrl] = useState(sub?.logo_url ?? "");
  const [color, setColor] = useState(sub?.color ?? "#7c3aed");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const upload = async (file: File) => {
    setUploading(true);
    const path = `${userId}/${crypto.randomUUID()}-${file.name}`;
    const { error } = await supabase.storage.from("subscription-logos").upload(path, file, { upsert: true });
    if (error) { setUploading(false); return toast.error(error.message); }
    const { data } = supabase.storage.from("subscription-logos").getPublicUrl(path);
    setLogoUrl(data.publicUrl);
    setUploading(false);
  };

  const onSave = async () => {
    if (!name.trim() || !amount) return toast.error("Name and amount are required");
    setSaving(true);
    const payload = {
      user_id: userId, name: name.trim(), category, amount: Number(amount), currency,
      billing_cycle: cycle, next_renewal: renewal, status, auto_renew: autoRenew,
      website: website || null, logo_url: logoUrl || null, color,
    };
    const { error } = sub
      ? await supabase.from("subscriptions").update(payload).eq("id", sub.id)
      : await supabase.from("subscriptions").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(sub ? "Updated" : "Added");
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" />
      <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-border bg-card shadow-glow">
        <div className="flex items-center justify-between border-b border-border p-5">
          <h3 className="font-display text-lg">{sub ? "Edit subscription" : "Add subscription"}</h3>
          <button onClick={onClose} className="rounded-lg p-2 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <div className="max-h-[70vh] space-y-4 overflow-y-auto p-5">
          <div className="flex items-center gap-3">
            <Logo url={logoUrl || null} name={name || "?"} color={color} />
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-border bg-secondary px-3 py-2 text-sm hover:bg-accent">
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Upload logo
              <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
            </label>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-12 cursor-pointer rounded-lg border border-border bg-transparent" />
          </div>

          <Field label="Name"><input value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="Netflix" /></Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Category">
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="input">
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Status">
              <select value={status} onChange={(e) => setStatus(e.target.value)} className="input">
                {["active", "paused", "cancelled", "expired"].map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Amount"><input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className="input" /></Field>
            <Field label="Currency"><input value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase())} className="input" /></Field>
            <Field label="Cycle">
              <select value={cycle} onChange={(e) => setCycle(e.target.value)} className="input">
                {["weekly", "monthly", "quarterly", "yearly"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
          </div>

          <Field label="Next renewal"><input type="date" value={renewal} onChange={(e) => setRenewal(e.target.value)} className="input" /></Field>
          <Field label="Website (optional)"><input value={website} onChange={(e) => setWebsite(e.target.value)} className="input" placeholder="https://" /></Field>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={autoRenew} onChange={(e) => setAutoRenew(e.target.checked)} className="h-4 w-4 accent-primary" /> Auto-renews
          </label>
        </div>
        <div className="flex justify-end gap-2 border-t border-border p-5">
          <button onClick={onClose} className="rounded-xl border border-border px-4 py-2 text-sm hover:bg-accent">Cancel</button>
          <button onClick={onSave} disabled={saving} className="inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-glow disabled:opacity-60">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save
          </button>
        </div>
      </div>
      <style>{`.input{width:100%;border-radius:12px;border:1px solid var(--color-input);background:var(--color-card);padding:.55rem .75rem;font-size:.875rem;outline:none}.input:focus{border-color:var(--color-primary);box-shadow:0 0 0 3px color-mix(in oklab,var(--color-primary) 25%,transparent)}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="text-xs font-medium text-muted-foreground">{label}</label><div className="mt-1">{children}</div></div>;
}
