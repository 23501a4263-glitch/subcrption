import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, Moon, Sun } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/lib/theme";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/settings")({ component: Page });

function Page() {
  const { theme, toggle } = useTheme();
  const [pw, setPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [saving, setSaving] = useState(false);

  const changePassword = async () => {
    if (pw.length < 8) return toast.error("At least 8 characters");
    if (pw !== confirm) return toast.error("Passwords don't match");
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    setPw(""); setConfirm("");
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-3xl">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">Tweak the app to your taste.</p>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium">Appearance</h3>
            <p className="text-sm text-muted-foreground">Switch between dark and light mode.</p>
          </div>
          <button onClick={toggle} className="inline-flex items-center gap-2 rounded-xl border border-border bg-secondary px-4 py-2 text-sm hover:bg-accent">
            {theme === "dark" ? <><Sun className="h-4 w-4" /> Light</> : <><Moon className="h-4 w-4" /> Dark</>}
          </button>
        </div>
      </div>

      <div className="glass space-y-4 rounded-2xl p-6">
        <div>
          <h3 className="font-medium">Change password</h3>
          <p className="text-sm text-muted-foreground">Use a strong, unique password.</p>
        </div>
        <div>
          <label className="text-sm font-medium">New password</label>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)}
            className="mt-1.5 w-full rounded-xl border border-input bg-card px-4 py-2.5 text-sm outline-none focus:border-primary" />
        </div>
        <div>
          <label className="text-sm font-medium">Confirm</label>
          <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)}
            className="mt-1.5 w-full rounded-xl border border-input bg-card px-4 py-2.5 text-sm outline-none focus:border-primary" />
        </div>
        <button onClick={changePassword} disabled={saving}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-glow disabled:opacity-60">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />} Update password
        </button>
      </div>
    </div>
  );
}
