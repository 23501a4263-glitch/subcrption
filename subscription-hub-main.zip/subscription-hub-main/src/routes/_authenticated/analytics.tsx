import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, Legend } from "recharts";
import { useAuth } from "@/lib/auth-context";
import { useSubscriptions } from "@/lib/use-subscriptions";
import { CATEGORY_COLORS, formatCurrency, monthlyAmount } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/analytics")({ component: Page });

function Page() {
  const { user } = useAuth();
  const { data } = useSubscriptions(user?.id);

  const byCategory = useMemo(() => {
    const m: Record<string, number> = {};
    data.filter((s) => s.status === "active").forEach((s) => {
      m[s.category] = (m[s.category] ?? 0) + monthlyAmount(Number(s.amount), s.billing_cycle);
    });
    return Object.entries(m).map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }));
  }, [data]);

  const monthlyTotal = byCategory.reduce((a, b) => a + b.value, 0);
  const yearly = monthlyTotal * 12;

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div>
        <h1 className="font-display text-3xl">Analytics</h1>
        <p className="mt-1 text-sm text-muted-foreground">Where your money is actually going.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Monthly" value={formatCurrency(monthlyTotal)} />
        <Stat label="Yearly run-rate" value={formatCurrency(yearly)} />
        <Stat label="Active categories" value={String(byCategory.length)} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-lg">Spend by category</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byCategory}>
                <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} tickLine={false} axisLine={false} width={40} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12 }} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {byCategory.map((d, i) => <Cell key={i} fill={CATEGORY_COLORS[d.name] ?? "var(--color-primary)"} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <h3 className="font-display text-lg">Distribution</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="name" outerRadius={90} label>
                  {byCategory.map((d, i) => <Cell key={i} fill={CATEGORY_COLORS[d.name] ?? "var(--color-primary)"} />)}
                </Pie>
                <Legend />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-2xl">{value}</p>
    </div>
  );
}
