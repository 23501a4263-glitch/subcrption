import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Sparkles } from "lucide-react";

export function AuthLayout({ title, subtitle, children, footer }: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background bg-mesh">
      <div className="grid min-h-screen lg:grid-cols-2">
        {/* Left: brand panel */}
        <div className="relative hidden overflow-hidden lg:flex lg:flex-col lg:justify-between p-12">
          <Link to="/" className="flex items-center gap-2 text-lg font-display font-semibold">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </span>
            Flux
          </Link>
          <div className="relative z-10">
            <h2 className="text-4xl font-display leading-tight">
              Stop bleeding money to <span className="text-gradient-primary">forgotten subscriptions.</span>
            </h2>
            <p className="mt-4 max-w-md text-muted-foreground">
              Flux gives you one calm dashboard for every recurring charge — Netflix, Notion, your AI bills, all of it.
            </p>
            <div className="mt-10 grid gap-3 max-w-md">
              {[
                "See exactly what you spend every month",
                "Get warned before the next renewal hits",
                "Cancel the ones you don't actually use",
              ].map((t) => (
                <div key={t} className="glass flex items-center gap-3 rounded-xl px-4 py-3 text-sm">
                  <span className="h-2 w-2 rounded-full bg-gradient-primary" /> {t}
                </div>
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-foreground">© {new Date().getFullYear()} Flux</div>
          {/* decorative orbs */}
          <div className="pointer-events-none absolute -left-20 top-1/2 h-72 w-72 rounded-full bg-gradient-primary opacity-30 blur-3xl" />
          <div className="pointer-events-none absolute -right-10 bottom-10 h-64 w-64 rounded-full bg-primary-glow opacity-20 blur-3xl" />
        </div>

        {/* Right: form */}
        <div className="flex items-center justify-center p-6 sm:p-12">
          <div className="w-full max-w-md">
            <Link to="/" className="mb-8 flex items-center gap-2 text-lg font-display font-semibold lg:hidden">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </span>
              Flux
            </Link>
            <h1 className="text-3xl font-display">{title}</h1>
            {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
            <div className="mt-8">{children}</div>
            {footer && <div className="mt-6 text-sm text-muted-foreground">{footer}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
