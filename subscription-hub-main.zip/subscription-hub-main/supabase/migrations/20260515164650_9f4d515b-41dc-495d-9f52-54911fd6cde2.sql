
-- ===== profiles =====
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  currency text not null default 'USD',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- updated_at trigger
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

-- auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end; $$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ===== subscriptions =====
create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text,
  category text not null default 'Other',
  amount numeric(12,2) not null default 0,
  currency text not null default 'USD',
  billing_cycle text not null default 'monthly', -- monthly | yearly | weekly | quarterly
  next_renewal date not null,
  started_on date not null default current_date,
  status text not null default 'active', -- active | paused | cancelled | expired
  auto_renew boolean not null default true,
  logo_url text,
  color text,
  website text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;

create policy "subs_select_own" on public.subscriptions for select using (auth.uid() = user_id);
create policy "subs_insert_own" on public.subscriptions for insert with check (auth.uid() = user_id);
create policy "subs_update_own" on public.subscriptions for update using (auth.uid() = user_id);
create policy "subs_delete_own" on public.subscriptions for delete using (auth.uid() = user_id);

create trigger subs_set_updated_at before update on public.subscriptions
for each row execute function public.set_updated_at();

create index subscriptions_user_id_idx on public.subscriptions(user_id);
create index subscriptions_next_renewal_idx on public.subscriptions(next_renewal);

-- ===== payments =====
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subscription_id uuid not null references public.subscriptions(id) on delete cascade,
  amount numeric(12,2) not null,
  currency text not null default 'USD',
  paid_on date not null default current_date,
  status text not null default 'paid', -- paid | failed | refunded | pending
  created_at timestamptz not null default now()
);
alter table public.payments enable row level security;

create policy "pay_select_own" on public.payments for select using (auth.uid() = user_id);
create policy "pay_insert_own" on public.payments for insert with check (auth.uid() = user_id);
create policy "pay_update_own" on public.payments for update using (auth.uid() = user_id);
create policy "pay_delete_own" on public.payments for delete using (auth.uid() = user_id);

create index payments_user_id_idx on public.payments(user_id);
create index payments_subscription_id_idx on public.payments(subscription_id);

-- ===== notifications =====
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subscription_id uuid references public.subscriptions(id) on delete cascade,
  title text not null,
  message text,
  type text not null default 'info', -- info | renewal | expiry | warning
  read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.notifications enable row level security;

create policy "notif_select_own" on public.notifications for select using (auth.uid() = user_id);
create policy "notif_insert_own" on public.notifications for insert with check (auth.uid() = user_id);
create policy "notif_update_own" on public.notifications for update using (auth.uid() = user_id);
create policy "notif_delete_own" on public.notifications for delete using (auth.uid() = user_id);

create index notifications_user_id_idx on public.notifications(user_id);

-- ===== storage bucket for subscription logos =====
insert into storage.buckets (id, name, public) values ('subscription-logos', 'subscription-logos', true);

create policy "logos_public_read" on storage.objects for select using (bucket_id = 'subscription-logos');
create policy "logos_user_insert" on storage.objects for insert with check (
  bucket_id = 'subscription-logos' and auth.uid()::text = (storage.foldername(name))[1]
);
create policy "logos_user_update" on storage.objects for update using (
  bucket_id = 'subscription-logos' and auth.uid()::text = (storage.foldername(name))[1]
);
create policy "logos_user_delete" on storage.objects for delete using (
  bucket_id = 'subscription-logos' and auth.uid()::text = (storage.foldername(name))[1]
);

-- avatars bucket
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true);

create policy "avatars_public_read" on storage.objects for select using (bucket_id = 'avatars');
create policy "avatars_user_insert" on storage.objects for insert with check (
  bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
);
create policy "avatars_user_update" on storage.objects for update using (
  bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
);
create policy "avatars_user_delete" on storage.objects for delete using (
  bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
);
