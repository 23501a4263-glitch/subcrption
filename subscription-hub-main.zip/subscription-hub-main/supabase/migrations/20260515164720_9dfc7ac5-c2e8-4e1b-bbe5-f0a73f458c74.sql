
-- Fix function search_path
create or replace function public.set_updated_at()
returns trigger language plpgsql
set search_path = public
as $$
begin new.updated_at = now(); return new; end; $$;

-- Restrict EXECUTE on SECURITY DEFINER and helper functions
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.set_updated_at() from public, anon, authenticated;

-- Drop broad public SELECT on storage objects (public URLs still work for public buckets)
drop policy if exists "logos_public_read" on storage.objects;
drop policy if exists "avatars_public_read" on storage.objects;
